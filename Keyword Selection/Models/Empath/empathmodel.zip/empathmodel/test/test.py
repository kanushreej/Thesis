from context import Empath

empath = Empath()

print(empath.analyze(["this","that"]))
print(empath.analyze(["this","that"]))
print(empath.analyze("the person typed on the keyboard"))
