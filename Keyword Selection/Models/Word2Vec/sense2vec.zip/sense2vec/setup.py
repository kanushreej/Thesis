#!/usr/bin/env python

if __name__ == "__main__":
    from setuptools import setup, find_packages

    setup(name="sense2vec", packages=find_packages())
